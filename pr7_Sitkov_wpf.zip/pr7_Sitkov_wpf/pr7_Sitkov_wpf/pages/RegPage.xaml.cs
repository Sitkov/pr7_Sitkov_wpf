﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.IO;    
using System.Text.Json;   
using System.Windows.Shapes;

namespace pr7_Sitkov_wpf.pages
{
    public partial class RegPage : Page
    {
        Doctor doctor = new();
        public RegPage()
        {
            InitializeComponent();
            DataContext = doctor;
        }

        private void Btn_Login_Doctor(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LoginPage());
        }
        private void Btn_Reg_Doctor(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text) ||
                string.IsNullOrWhiteSpace(LastNameBox.Text) ||
                string.IsNullOrWhiteSpace(MiddleNameBox.Text) ||
                string.IsNullOrWhiteSpace(SpecialisationBox.Text) ||
                string.IsNullOrWhiteSpace(pass1.Text) ||
                string.IsNullOrWhiteSpace(pass2.Text))
            {
                MessageBox.Show("Нужно заполнить все поля!!!");
            }
            else if (pass1.Text.ToString() != pass2.Text.ToString())
            {
                MessageBox.Show("Пароли не совпадают!!!");
            }
            else
            {
                doctor.ID = doctor.randomID();
                var jsonStr = JsonSerializer.Serialize(doctor);
                Doctor fromJson = JsonSerializer.Deserialize<Doctor>(jsonStr);
                NavigationService.Navigate(new MainDoctorPage(fromJson));
                MessageBox.Show($"Успешная регистрация! Ваш уникальный номер - '{doctor.ID}'\n" +
                    $"Запомните его!!!");

                using (StreamWriter sw = new StreamWriter($"D_{doctor.ID}.json"))
                {
                    sw.Write(jsonStr);
                }
                NameBox.Text = "";
                LastNameBox.Text = "";
                MiddleNameBox.Text = "";
                SpecialisationBox.Text = "";
                pass1.Text = "";
                pass2.Text = "";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.Json;

namespace pr7_Sitkov_wpf.pages
{
    /// <summary>
    /// Логика взаимодействия для ChangeInfoPatient.xaml
    /// </summary>
    public partial class ChangeInfoPatient : Page
    {
        Patient patient = new();
        Patient patientChange = new();
        public ChangeInfoPatient(Patient mainPatient)
        {
            InitializeComponent();
            patient = mainPatient;
            this.DataContext = patient;
            patientChange = patient;
        }

        private void Btn_Reset_Change(object sender, RoutedEventArgs e)
        {
            string fileName = $"P_{patient.ID}.json";
            if (File.Exists(fileName))
            {
                var jsonStr = File.ReadAllText(fileName);
                Patient fromJson = JsonSerializer.Deserialize<Patient>(jsonStr);
                patient = fromJson;
                changeName.Text = patient.Name;
                changeLastName.Text = patient.LastName;
                changeMiddleName.Text = patient.MiddleName;
                changeBirthday.Text = patient.Birthday;
                changeLastAppointment.Text = patient.LastAppointment;
                changeDiagnosis.Text = patient.Diagnosis;
                changeRecomendations.Text = patient.Recomendations;
                changePhoneNumber.Text = patient.PhoneNumber;
            }
            else
            {
                MessageBox.Show("Пациент не найден!!!");
            }
        }

        private void Btn_Save_Change(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(changeName.Text) ||
                 string.IsNullOrWhiteSpace(changeLastName.Text) ||
                 string.IsNullOrWhiteSpace(changeMiddleName.Text) ||
                 string.IsNullOrWhiteSpace(changeBirthday.Text) ||
                 string.IsNullOrWhiteSpace(changeLastAppointment.Text) ||
                 string.IsNullOrWhiteSpace(changeDiagnosis.Text) ||
                 string.IsNullOrWhiteSpace(changeRecomendations.Text))
            {
                MessageBox.Show("Заполните все поля!!!");
            }
            else
            {
                patientChange.ID = patient.ID;
                patientChange.Name = changeName.Text;
                patientChange.LastName = changeLastName.Text;
                patientChange.MiddleName = changeMiddleName.Text;
                patientChange.Birthday = changeBirthday.Text;
                patientChange.LastAppointment = changeLastAppointment.Text;
                patientChange.Diagnosis = changeDiagnosis.Text;
                patientChange.Recomendations = changeRecomendations.Text;
                patientChange.LastDoctor = patient.LastDoctor;
                var jsonStr = JsonSerializer.Serialize(patientChange);

                using (StreamWriter sw = new StreamWriter($"P_{patientChange.ID}.json"))
                {
                    sw.Write(jsonStr);
                }
                Patient fromJson = JsonSerializer.Deserialize<Patient>(jsonStr);
                patient = fromJson;

                NavigationService.GoBack();
            }
        }
    }
}

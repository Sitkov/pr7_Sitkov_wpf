﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr7_Sitkov_wpf.pages
{
    public partial class MainDoctorPage : Page
    {
        Doctor doctor = new();

        public ObservableCollection<Patient> Patients { get; set; } = new ObservableCollection<Patient>();  
        public MainDoctorPage(Doctor heDoctor)
        {
            InitializeComponent();
            doctor = heDoctor;
            DataContext = doctor;
            LoadPatients();
            ListPatients.DataContext = Patients;
        }

        public void LoadPatients()
        {
            Patients.Clear();
            string[] files = Directory.GetFiles(Directory.GetCurrentDirectory(), "P_*.json");

            foreach (string file in files)
            {
                string jsonStr = File.ReadAllText(file);
                Patient fromJson = JsonSerializer.Deserialize<Patient>(jsonStr);
                Patients.Add(fromJson);
            }
        }

        private void Btn_AddPatient_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new CreatePatient(doctor));
        }

        private void PageLoad(object sender, RoutedEventArgs e)
        {
            LoadPatients();
        }

        private void Btn_ChangePatient_Click(object sender, RoutedEventArgs e)
        {
            Patient selected = ListPatients.SelectedItem as Patient;

            if (selected == null)
            {
                MessageBox.Show("Выберете пациента!");
            }
            else
            {
                NavigationService.Navigate(new ChangeInfoPatient(selected));
            }
        }

        private void Btn_PriemPatient_Click(object sender, RoutedEventArgs e)
        {
            Patient selected = ListPatients.SelectedItem as Patient;

            if (selected == null)
            {
                MessageBox.Show("Выберете пациента!");
            }
            else
            {
                NavigationService.Navigate(new AppointmentPage(selected, doctor));
            }
        }

        private void Btn_DeletePatient_Click(object sender, RoutedEventArgs e)
        {
            Patient selected = ListPatients.SelectedItem as Patient;
            if (selected == null)
            {
                MessageBox.Show("Выберете пациента");
            }
            else
            {
                File.Delete($"P_{selected.ID}.json");
                LoadPatients();
                MessageBox.Show("Успешно удален");
            }
        }
    }
}

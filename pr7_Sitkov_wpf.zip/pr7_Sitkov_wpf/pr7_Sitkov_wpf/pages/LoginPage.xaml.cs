﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr7_Sitkov_wpf.pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        Doctor doctor = new();
        public LoginPage()
        {
            InitializeComponent();
        }
        private void Btn_Reg_Doctor(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegPage());
        }

        private void Btn_Login_Doctor(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(passwordBox.Text) ||
                string.IsNullOrWhiteSpace(loginBox.Text))
            {
                MessageBox.Show("Забыли ввести логин или пароль!!!");
            }
            else
            {
                string fileName = $"D_{loginBox.Text}.json";
                if (File.Exists(fileName))
                {
                    var jsonStr = File.ReadAllText(fileName);
                    Doctor fromJson = JsonSerializer.Deserialize<Doctor>(jsonStr);

                    if (passwordBox.Text == fromJson.Password)
                    {
                        doctor = fromJson;
                        NavigationService.Navigate(new MainDoctorPage(fromJson));
                        MessageBox.Show("Успешная авторизация!");
                    }
                    else
                    {
                        MessageBox.Show("Неверный пароль!");
                    }
                }
                else
                {
                    MessageBox.Show("Доктор с таким номером не найден!!!");
                }
            }
        }

        

        //private void Btn_Search_Patient(object sender, RoutedEventArgs e)
        //{
        //    if (string.IsNullOrWhiteSpace(searchBox.Text))
        //    {
        //        MessageBox.Show("Нужно заполнить полe!!!");
        //    }
        //    else
        //    {
        //        string fileName = $"P_{searchBox.Text}.json";
        //        if (File.Exists(fileName))
        //        {
        //            var jsonStr = File.ReadAllText(fileName);
        //            Patient fromJson = JsonSerializer.Deserialize<Patient>(jsonStr);
        //            patientInfo = fromJson;
        //            patientInfo.LastAppointment = today;
        //            patientInfo.LastDoctor = doctorInfo.ID;
        //            InfoPatientData.Visibility = Visibility.Visible;
        //            InfoPatientData.DataContext = patientInfo;
        //            searchBox.Text = "";
        //            changeName.Text = patientInfo.Name;
        //            changeLastName.Text = patientInfo.LastName;
        //            changeMiddleName.Text = patientInfo.MiddleName;
        //            changeBirthday.Text = patientInfo.Birthday;
        //            changeLastAppointment.Text = patientInfo.LastAppointment;
        //            changeDiagnosis.Text = patientInfo.Diagnosis;
        //            changeRecomendations.Text = patientInfo.Recomendations;
        //            changeInfoPatient.IsEnabled = true;
        //        }
        //        else
        //        {
        //            MessageBox.Show("Пациент не найден!!!");

        //        }
        //    }
        //}


    }
}

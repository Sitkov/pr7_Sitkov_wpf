﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.Json;

namespace pr7_Sitkov_wpf.pages
{
    public partial class AppointmentPage : Page
    {
        Patient patient = new();
        Doctor doctor = new();
        public AppointmentRecord NewRecord { get; set; } = new AppointmentRecord();
        public AppointmentPage(Patient mainPatient, Doctor mainDoctor)
        {
            InitializeComponent();
            patient = mainPatient;
            doctor = mainDoctor;

            NewRecord.DoctorId = doctor.ID;
            NewRecord.Date = DateTime.Now.ToShortDateString();
            this.DataContext = patient;
            RightInputPanel.DataContext = NewRecord;
        }

        private void Btn_Save_Click(object sender, RoutedEventArgs e)
        {
            patient.AppointmentStories.Add(new AppointmentRecord
            {
                Date = NewRecord.Date,
                DoctorId = NewRecord.DoctorId,
                Diagnosis = NewRecord.Diagnosis,
                Recommendations = NewRecord.Recommendations
            });

            string jsonStr = JsonSerializer.Serialize(patient);
            using (StreamWriter sw = new StreamWriter($"P_{patient.ID}.json"))
            {
                sw.Write(jsonStr);
            }

            MessageBox.Show("Прием сохранен!");
        }

        private void back(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}

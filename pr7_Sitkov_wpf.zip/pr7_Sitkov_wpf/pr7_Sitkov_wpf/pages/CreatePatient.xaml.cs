﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Text.Json;
using pr7_Sitkov_wpf.pages;

namespace pr7_Sitkov_wpf.pages
{
    /// <summary>
    /// Логика взаимодействия для CreatePatient.xaml
    /// </summary>
    public partial class CreatePatient : Page
    {
        Doctor doctor = new();
        Patient patient = new();
        string today = "24.12.2025";
        public CreatePatient(Doctor mainDoc)
        {
            InitializeComponent();

            doctor = mainDoc;
            DataContext = patient;
        }

        private void Btn_Add_Patient(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(nameBox.Text) ||
                string.IsNullOrWhiteSpace(lastNameBox.Text) ||
                string.IsNullOrWhiteSpace(middleNameBox.Text) ||
                string.IsNullOrWhiteSpace(birthdayBox.Text))
            {
                MessageBox.Show("Нужно заполнить все поля!!!");
            }
            else
            {
                patient.PhoneNumber = "8900";
                patient.LastAppointment = today;
                patient.LastDoctor = doctor.ID;
                patient.ID = patient.randomID();
                var jsonStr = JsonSerializer.Serialize(patient);
                Patient fromJson = JsonSerializer.Deserialize<Patient>(jsonStr);
                using (StreamWriter sw = new StreamWriter($"P_{patient.ID}.json"))
                {
                    sw.Write(jsonStr);
                }
                NavigationService.GoBack();
                MessageBox.Show($"Успешнo! Уникальный номер пациента - '{patient.ID}'\n" +
                    $"Запомните его!!!");

            }
        }
    }
}

﻿using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using pr7_Sitkov_wpf.pages;

namespace pr7_Sitkov_wpf
{

    public partial class MainWindow : Window
    {
        public Doctor doctor = new();
        public Patient patient = new();
        public Doctor doctorInfo = new();
        public Patient patientInfo = new();
        public Patient patientChange = new();
        string today = "12/12/2025";
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new LoginPage());

        }

        private void ChangeTheme_Click(object sender, RoutedEventArgs e)
        {
            ThemeHelper.ToggleTheme();
        }
    }
}
﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace pr7_Sitkov_wpf
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}

﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace pr7_Sitkov_wpf.Converters
{
    public class LastVisitConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string dateStr && DateTime.TryParse(dateStr, out DateTime lastVisit))
            {
                var diff = (DateTime.Today - lastVisit).Days;
                if (diff == 0) return "Был сегодня";
                return $"Прошло дней: {diff}";
            }
            // Если даты нет или она некорректна - считаем, что это первый прием
            return "Первый прием в клинике";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
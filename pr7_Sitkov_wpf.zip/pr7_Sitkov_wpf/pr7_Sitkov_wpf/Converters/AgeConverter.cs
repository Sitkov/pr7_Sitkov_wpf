﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace pr7_Sitkov_wpf.Converters
{
    public class AgeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string dateStr && DateTime.TryParse(dateStr, out DateTime birthDate))
            {
                var today = DateTime.Today;
                var age = today.Year - birthDate.Year;
                if (birthDate.Date > today.AddYears(-age)) age--;

                string status = age >= 18 ? "Совершеннолетний" : "Несовершеннолетний";
                return $"{age} лет ({status})";
            }
            return "Некорректная дата";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace pr7_Sitkov_wpf.Converters
{
    public class PhoneConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string phone = value as string;
            if (string.IsNullOrEmpty(phone)) return phone;

            // Оставляем только цифры
            string digits = new string(phone.Where(char.IsDigit).ToArray());

            if (digits.Length == 11)
            {
                // Формат: # (###) ### ## ##
                return long.Parse(digits).ToString("# (###) ### ## ##");
            }
            return phone;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // Возвращаем просто строку, если нужно
            return value?.ToString();
        }
    }
}
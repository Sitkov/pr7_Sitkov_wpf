﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace pr7_Sitkov_wpf
{
    public class Patient : INotifyPropertyChanged
    {
        private static int idPatient;
        private string _name = "";
        private string _lastName = "";
        private string _middleName = "";
        private string _birthday = "";
        private string _lastAppointment = "";
        private int _lastDoctor;
        private string _diagnosis = "";
        private string _recomendations = "";
        private string _phoneNumber;
        private ObservableCollection<AppointmentRecord> _appointmentStories = new();

        public string PhoneNumber
        {
            get => _phoneNumber;
            set { _phoneNumber = value; OnPropertyChanged(); }
        }

        public ObservableCollection<AppointmentRecord> AppointmentStories
        {
            get => _appointmentStories;
            set { _appointmentStories = value; OnPropertyChanged(); }
        }
        public int ID
        {
            get => idPatient;
            set
            {
                if (idPatient != value)
                {
                    idPatient = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (_name != value)
                {
                    _name = value;
                    OnPropertyChanged();
                }
            }
        }

        public string LastName
        {
            get => _lastName;
            set
            {
                if (_lastName != value)
                {
                    _lastName = value;
                    OnPropertyChanged();
                }
            }
        }

        public string MiddleName
        {
            get => _middleName;
            set
            {
                if (_middleName != value)
                {
                    _middleName = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Birthday
        {
            get => _birthday;
            set
            {
                if (_birthday != value)
                {
                    _birthday = value;
                    OnPropertyChanged();
                }
            }
        }
        public string LastAppointment
        {
            get => _lastAppointment;
            set
            {
                if (_lastAppointment != value)
                {
                    _lastAppointment = value;
                    OnPropertyChanged();
                }
            }
        }

        public int LastDoctor
        {
            get => _lastDoctor;
            set
            {
                if (_lastDoctor != value)
                {
                    _lastDoctor = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Diagnosis
        {
            get => _diagnosis;
            set
            {
                if (_diagnosis != value)
                {
                    _diagnosis = value;
                    OnPropertyChanged();
                }
            }
        }

        public string Recomendations
        {
            get => _recomendations;
            set
            {
                if (_recomendations != value)
                {
                    _recomendations = value;
                    OnPropertyChanged();
                }
            }
        }
        public int id = 1000000;
        public int randomID()
        {
            id++;
            return id;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }
}

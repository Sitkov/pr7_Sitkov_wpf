﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr7_Sitkov_wpf
{
    public class AppointmentRecord
    {
        public string Date { get; set; }
        public int DoctorId { get; set; }
        public string Diagnosis { get; set; }
        public string Recommendations { get; set; }
    }
}

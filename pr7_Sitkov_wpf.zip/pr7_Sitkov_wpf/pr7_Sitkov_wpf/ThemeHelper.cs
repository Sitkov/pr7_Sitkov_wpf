﻿using System;
using System.Linq; 
using System.Windows; 

namespace pr7_Sitkov_wpf
{
    public static class ThemeHelper
    {
        private static readonly string LightPath = "styles/colors/Light.xaml";
        private static readonly string DarkPath = "styles/colors/Dark.xaml";

        public static bool IsDarkTheme { get; private set; } = false;

        public static void ToggleTheme()
        {
            string newThemePath = IsDarkTheme ? LightPath : DarkPath;

            IsDarkTheme = !IsDarkTheme;

            var newThemeDict = new ResourceDictionary { Source = new Uri(newThemePath, UriKind.Relative) };

            var appResources = Application.Current.Resources.MergedDictionaries;

            var oldThemeDict = appResources.FirstOrDefault(d => d.Source != null &&
                (d.Source.OriginalString.Contains("Light.xaml") || d.Source.OriginalString.Contains("Dark.xaml")));

            if (oldThemeDict != null)
            {
                appResources.Remove(oldThemeDict);
            }

            appResources.Insert(0, newThemeDict);
        }
    }
}